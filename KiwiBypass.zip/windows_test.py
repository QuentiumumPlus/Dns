import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from main import KiwiBypassApp

if __name__ == "__main__":
    KiwiBypassApp().run()
